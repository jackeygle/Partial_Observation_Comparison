import yaml
import numpy as np
import os
import torch
from .utils import *

dir_path = os.path.dirname(os.path.realpath(__file__))
yaml_path = os.path.join(dir_path, 'Parameters.yaml')
with open(yaml_path, 'r') as file:
    params = yaml.safe_load(file)

# Which gain implementation LocalizedEnsembleKalmanFilter uses when the caller does not say.
# Settable from the environment so an existing driver can be A/B'd without editing it:
#   ENKF_GAIN_MODE=pinv      (default) bit-identical to enkf_lab
#   ENKF_GAIN_MODE=ensemble            same gain via Woodbury; ~10x on the analysis step, not
#                                      bit-identical. See enkf_opt/README.md for the measured
#                                      deviation before reporting anything computed with it.
GAIN_MODES = ("pinv", "ensemble")
DEFAULT_GAIN_MODE = os.environ.get("ENKF_GAIN_MODE", "pinv")

# Multiplier applied to the calibrated process noise before it is injected each forecast step.
# The reference hard-codes 0.01 -- i.e. 1% of the PROC_STD that estimate_noise_from_data()
# measured as the surrogate's OWN one-step error, which is exactly the quantity a textbook EnKF
# injects at full strength. That one constant sets the ensemble's equilibrium spread: measured
# on enkf_k1_full, the spread settles at 1.0-1.9x the injected level within ~5 frames and is
# then static for the remaining ~39,800 frames of the day. Exposed here so it can be swept.
#   ENKF_PROC_SCALE=0.01  (default) the reference value; this path stays bit-identical to lab
#   ENKF_PROC_SCALE=1.0             inject the full calibrated process noise
DEFAULT_PROC_SCALE = float(os.environ.get("ENKF_PROC_SCALE", "0.01"))


def _obs_indices(C):
    """`C.nonzero()[1]` -- the state index each observation row reads -- plus a flag saying
    whether C is a pure selection matrix (exactly one 1.0 per row, which is what every caller
    in this project builds).

    `C.nonzero()` scans C and then materialises two index arrays; the reference `update()`
    calls it THREE times per assimilation step (once in the observed_cells fallback, twice for
    obs_idx) at ~9 ms each for a 1008 x 1728 C, i.e. ~13% of a step spent recomputing one
    fixed array. argmax plus a total nonzero count answers the same question in two cheap
    passes and returns the identical indices for a selection matrix; anything else falls back
    to the original call, so the result is always exactly `C.nonzero()[1]`.
    """
    m = C.shape[0]
    idx = C.argmax(axis=1)
    if np.count_nonzero(C) == m and np.all(C[np.arange(m), idx] == 1.0):
        return idx, True
    return C.nonzero()[1], False


def _add_to_diagonal(A, value):
    """A[i, i] += value, in place, without building a dense diagonal matrix to add."""
    n = A.shape[0]
    A.reshape(-1)[::n + 1] += value
    return A

class GeneratePartialObs:
    def __init__(self, GRID_SIZE, STATE_SHAPE, agent_pos, sensing_range ):
        self.GRID_SIZE = GRID_SIZE
        self.STATE_SHAPE =STATE_SHAPE
        self.agent_pos = agent_pos
        self.sensing_range = sensing_range

        self.num_features = STATE_SHAPE[0]
        self.total_cells = GRID_SIZE[0] * GRID_SIZE[1]
        self.state_dim = np.prod(STATE_SHAPE)


    def cells_within_range(self):
        """Cells within `sensing_range` of the agent, in row-major order.

        Vectorised; the original scanned the grid with a double Python loop. The float
        sequence is unchanged (sqrt of the integer squared distance, compared to the radius),
        and row-major order is preserved because that order fixes the row order of C.
        """
        rows, cols = self.GRID_SIZE
        r0, c0 = self.agent_pos
        dr = np.arange(rows)[:, None] - r0
        dc = np.arange(cols)[None, :] - c0
        inside = np.sqrt(dr ** 2 + dc ** 2) <= self.sensing_range
        r_idx, c_idx = np.nonzero(inside)
        return list(zip(r_idx.tolist(), c_idx.tolist()))

    def get_observation_matrix(self):
        """Selection matrix C, one row per (observed cell, feature).

        Same 0/1 pattern as the original double loop, written with one fancy-index assignment.
        """
        observed_cells = self.cells_within_range()
        F = self.num_features
        m = F * len(observed_cells)
        C = np.zeros((m, self.state_dim))
        if m:
            cells = np.asarray(observed_cells)
            base = cells[:, 0] * self.GRID_SIZE[1] + cells[:, 1]          # r*W + c
            f = np.arange(F)
            cols = (f * self.total_cells)[None, :] + base[:, None]        # (n_cells, F)
            C[np.arange(m), cols.reshape(-1)] = 1.0
        return C, observed_cells

    def reconstruct_observation(self, obs_vector, C, fill_value=np.nan):
        """Rebuild (features, rows, cols) observation with missing entries filled,
           using the actual observation matrix C."""
        reconstructed = np.full(self.STATE_SHAPE, fill_value, dtype=float)

        # For each row in C, find which state variable it maps to. Scattering in one call
        # keeps the original's last-write-wins behaviour for indices that repeat (which they
        # do whenever two agents' ranges overlap and their C blocks are stacked).
        obs_indices = C.nonzero()[1]  # column indices
        reconstructed.reshape(-1)[obs_indices] = np.asarray(obs_vector)[:len(obs_indices)]

        return reconstructed

class MultiAgent:
    def __init__(self, grid_size, state_shape, sensing_range, num_agents=2):
        self.grid_size = grid_size
        self.state_shape = state_shape
        self.sensing_range = sensing_range
        self.num_agents = num_agents

        # Random initial positions and goals
        self.positions = [
            (np.random.randint(0, grid_size[0]), np.random.randint(0, grid_size[1]))
            for _ in range(num_agents)
        ]
        self.goals = [
            (np.random.randint(0, grid_size[0]), np.random.randint(0, grid_size[1]))
            for _ in range(num_agents)
        ]

    def move_agents(self):
        """Move each agent one step toward its goal (Manhattan greedy)."""
        new_positions = []
        for (r, c), (gr, gc) in zip(self.positions, self.goals):
            dr = np.sign(gr - r)
            dc = np.sign(gc - c)
            new_r = min(max(r + dr, 0), self.grid_size[0] - 1)
            new_c = min(max(c + dc, 0), self.grid_size[1] - 1)
            new_positions.append((new_r, new_c))
        self.positions = new_positions

    def get_joint_observation(self):
        """Return combined observation from all agents."""
        all_cells = set()
        C_blocks = []
        for pos in self.positions:
            obs_gen = GeneratePartialObs(self.grid_size, self.state_shape, pos, self.sensing_range)
            C, cells = obs_gen.get_observation_matrix()
            all_cells.update(cells)
            C_blocks.append(C)

        # Merge by stacking (can also deduplicate if needed)
        C_joint = np.vstack(C_blocks)
        return C_joint, sorted(all_cells)

class EnsembleKalmanFilter:
    def __init__(self, grid_size, state_shape, ensemble_size=200,
                 proc_noise_std=(0.03435, 0.1899, 0.05144, 0.003886),
                 obs_noise_std=(0.05726, 0.3165, 0.08573, 0.006477),
                 init_perturb_std=(0.2290, 1.2660, 0.3429, 0.0259),
                 inflation=1.0, seed=0, proc_noise_scale=None):

        self.grid_size = grid_size
        self.state_shape = state_shape
        self.ensemble_size = ensemble_size
        self.num_features = state_shape[0]
        self.state_dim = np.prod(state_shape)
        self.rng = np.random.RandomState(seed)
        self.inflation = inflation

        # Noise vectors
        self.proc_noise_vec = self._expand_noise(proc_noise_std)
        self.obs_noise_vec = self._expand_noise(obs_noise_std)
        self.init_std_vec = self._expand_noise(init_perturb_std)
        # Hoisted out of forecast(): same value every call, allocated every call in the original
        self.proc_noise_scale = (DEFAULT_PROC_SCALE if proc_noise_scale is None
                                 else float(proc_noise_scale))
        self._proc_step_vec = self.proc_noise_scale * self.proc_noise_vec

        self.X = None

    def get_std(self):
        """Returns per-feature std across ensemble, reshaped to state shape."""
        if self.X is None:
            raise ValueError("Ensemble not initialized.")
        return np.std(self.X, axis=0).reshape(self.state_shape)

    def _expand_noise(self, std_per_feature):
        H, W = self.grid_size
        return np.concatenate([np.full(H * W, s) for s in std_per_feature])

    def initialize(self, init_state):
        """Initialize ensemble with perturbations + clipping"""
        mean_state = init_state.flatten()
        self.X = np.tile(mean_state, (self.ensemble_size, 1)) + \
                 self.rng.normal(0, self.init_std_vec * 0.5, size=(self.ensemble_size, self.state_dim))
        self.X = self._clip_bounds(self.X)

    def _clip_bounds(self, X):
        """Apply physical bounds: density [0,5], vx/vy [-5,5], variance [0,2]

        Writes straight into a fresh buffer instead of `X.copy()` followed by four clips into
        it: same four clips, same per-slice dtype promotion (the bounds stay Python ints so a
        float32 ensemble stays float32), one pass over the array instead of two.
        """
        H, W = self.grid_size
        feature_size = H * W
        out = np.empty_like(X)
        np.clip(X[:, :feature_size], 0, 5, out=out[:, :feature_size])                            # density
        np.clip(X[:, feature_size:2*feature_size], -5, 5, out=out[:, feature_size:2*feature_size])  # vx
        np.clip(X[:, 2*feature_size:3*feature_size], -5, 5, out=out[:, 2*feature_size:3*feature_size])  # vy
        np.clip(X[:, 3*feature_size:], 0, 2, out=out[:, 3*feature_size:])                        # variance
        return out

    def _f_model(self, x_np_batch, model):
        """Push the ensemble through the surrogate one step.

        `torch.from_numpy` on an already-float32 buffer instead of `torch.tensor(float64,
        dtype=float32)` saves one full copy of the batch, and the device is taken from the
        model instead of being hard-coded to CPU -- with the hard-coded version a model loaded
        on a GPU (as ENKF.main() does) crashes on a device mismatch.
        """
        N = x_np_batch.shape[0]
        x_np = np.ascontiguousarray(x_np_batch, dtype=np.float32).reshape(N, 1, *self.state_shape)
        x_torch = torch.from_numpy(x_np)
        try:
            device = next(model.parameters()).device
        except (StopIteration, AttributeError):
            device = None
        if device is not None and device.type != "cpu":
            x_torch = x_torch.to(device, non_blocking=True)
        with torch.no_grad():
            y_torch = model(x_torch, horizon=1)
        return y_torch.cpu().numpy().reshape(N, -1)

    def forecast(self, model):
        if model is None:
            X_f = self.X.copy()
        else:
            X_f = self._f_model(self.X, model)

        # Add small process noise. Kept as an in-place add: X_f is float32 when it comes out of
        # the surrogate, and `X_f = X_f + noise` would silently promote it to float64.
        X_f += self.rng.normal(0, self._proc_step_vec, size=X_f.shape)
        return self._clip_bounds(X_f)

    def update(self, X_f, C, y_obs, regularization=1e-3, obs_idx=None):
        N = self.ensemble_size
        if obs_idx is None:
            obs_idx, _ = _obs_indices(C)

        Y_f = (C @ X_f.T).T
        y_mean = np.mean(Y_f, axis=0)

        X_mean = np.mean(X_f, axis=0)
        X_ano = X_f - X_mean
        Y_ano = Y_f - y_mean

        r_diag = self.obs_noise_vec[obs_idx] ** 2
        r_sqrt = np.sqrt(r_diag)                       # was recomputed inside the member loop

        P_xy = (X_ano.T @ Y_ano) / (N - 1)
        # R and regularization*eye are diagonal: add them to the diagonal in place instead of
        # materialising two m x m dense matrices (8 MB each at m=1008) and adding them whole.
        P_yy = (Y_ano.T @ Y_ano) / (N - 1)
        _add_to_diagonal(P_yy, r_diag)
        _add_to_diagonal(P_yy, regularization)

        K = P_xy @ np.linalg.pinv(P_yy)  # safer

        X_a = np.empty_like(X_f)
        for i in range(N):
            perturbed_y = y_obs + self.rng.normal(0, r_sqrt)
            X_a[i] = X_f[i] + K @ (perturbed_y - Y_f[i])

        # Inflation, in place: X_mean + inflation*(X_a - X_mean) with two fewer temporaries.
        X_mean = np.mean(X_a, axis=0)
        X_a -= X_mean
        X_a *= self.inflation
        X_a += X_mean

        # Clip after inflation
        self.X = self._clip_bounds(X_a)
        return self.X

    def step(self, C, y_obs, model=None):
        X_f = self.forecast(model=model)
        X_a = self.update(X_f, C, y_obs)
        return X_a.mean(axis=0).reshape(self.state_shape)

class LocalizedEnsembleKalmanFilter:
    """Localized EnKF with the NN surrogate as the forecast model.

    `gain_mode` selects how the Kalman gain is evaluated. The mathematics is the same in both
    cases; the arithmetic is not:

      "pinv"     (default) the original expression, K = (P_xy @ pinv(P_yy)) * Loc.T. Every
                 optimisation on this path is bookkeeping -- dead recomputation, redundant
                 allocations, Python loops -- so results stay BIT-IDENTICAL to enkf_lab, which
                 is the rule this copy has to obey (see enkf_opt/README.md).
      "ensemble" the same gain rewritten in ensemble space (Woodbury), which replaces the
                 m x m SVD and the state_dim x m x m product by an N x N solve. Measured ~10x
                 on the analysis step (~130 ms -> ~13 ms at m~800, N=100), and the gap widens
                 with m because the SVD is O(m^3) while this form is linear in m. NOT
                 bit-identical: it is a different (better-conditioned) sequence of floating
                 point operations, so any number produced with it has to be reported as such.
                 checks/verify_enkf_gain_mode.py measures what that costs over a whole day.

    Default is taken from $ENKF_GAIN_MODE so existing drivers can be switched without an edit.
    """

    def __init__(self, grid_size, state_shape, ensemble_size=200,
                 proc_noise_std=(0.03435, 0.1899, 0.05144, 0.003886),
                 obs_noise_std=(0.05726, 0.3165, 0.08573, 0.006477),
                 init_perturb_std=(0.2290, 1.2660, 0.3429, 0.0259),
                 inflation=1.02, localization_radius=7, seed=0, gain_mode=None,
                 proc_noise_scale=None, use_gain=True, use_bias=True,
                 fix_localization=False):

        self.grid_size = grid_size
        self.state_shape = state_shape
        self.ensemble_size = ensemble_size
        self.num_features = state_shape[0]
        self.state_dim = np.prod(state_shape)
        self.rng = np.random.RandomState(seed)
        self.inflation = inflation
        self.localization_radius = localization_radius
        self.gain_mode = DEFAULT_GAIN_MODE if gain_mode is None else gain_mode
        if self.gain_mode not in GAIN_MODES:
            raise ValueError(f"gain_mode must be one of {GAIN_MODES}, got {self.gain_mode!r}")
        # Diagnostic switches for the two correction paths this filter actually has. Both
        # default to True, i.e. the shipped behaviour; see forecast() and update().
        self.use_gain = bool(use_gain)
        self.use_bias = bool(use_bias)
        # False = the published behaviour (only density is ever assimilated). See update().
        self.fix_localization = bool(fix_localization)
        # Read-only gain census, off by default. When on, update() appends one dict per
        # assimilation to self.gain_stats. Nothing is read back, so the numerics are untouched;
        # the only cost on the shipped path is one `if` per step. See checks/diag_gain_census.py.
        self.collect_stats = False
        self.gain_stats = []

        # Noise vectors
        self.proc_noise_vec = self._expand_noise(proc_noise_std)
        self.obs_noise_vec = self._expand_noise(obs_noise_std)
        self.init_std_vec = self._expand_noise(init_perturb_std)
        # Hoisted out of forecast(): same value every call, allocated every call in the original
        self.proc_noise_scale = (DEFAULT_PROC_SCALE if proc_noise_scale is None
                                 else float(proc_noise_scale))
        self._proc_step_vec = self.proc_noise_scale * self.proc_noise_vec

        self.X = None

        #estimatin NN model bias
        self.bias_estimate = np.zeros(int(self.state_dim))  # per-state bias estimate
        self.bias_ema_alpha = 0.05  # smoothing factor for EMA; tune 0.01-0.2
    ###########added for estimating NN model bias
    def _backproject_obs_bias(self, obs_idx, obs_bias):
        """
        obs_idx: array of column indices in state vector that each observed row corresponds to (C.nonzero()[1])
        obs_bias: vector of length m (observation-space bias = y_obs - predicted_obs)
        Returns: state_dim vector with non-zero entries at obs_idx (feature-level)

        One scatter instead of a 1008-iteration Python loop. numpy assigns fancy indices in
        order, so repeated indices keep the original's last-write-wins result (they repeat
        whenever two agents' sensing ranges overlap and their C blocks are stacked).
        """
        b = np.zeros(self.state_dim)
        # Each obs row corresponds to a single state variable (since C rows are selection rows)
        # So assign the obs_bias directly to the corresponding state index.
        b[obs_idx] = obs_bias
        return b

    ###########
    def get_std(self):
        if self.X is None:
            raise ValueError("Ensemble not initialized.")
        return np.std(self.X, axis=0).reshape(self.state_shape)

    def _expand_noise(self, std_per_feature):
        H, W = self.grid_size
        return np.concatenate([np.full(H * W, s) for s in std_per_feature])

    def initialize(self, init_state):
        mean_state = init_state.flatten()
        self.X = np.tile(mean_state, (self.ensemble_size, 1)) + \
                 self.rng.normal(0, self.init_std_vec * 0.5, size=(self.ensemble_size, self.state_dim))
        self.X = self._clip_bounds(self.X)

    def _clip_bounds(self, X):
        """Physical bounds: density [0,5], vx/vy [-5,5], variance [0,2].

        Clips straight into a fresh buffer instead of `X.copy()` plus four clips into it: same
        four clips, same per-slice dtype behaviour (the bounds stay Python ints, so a float32
        ensemble stays float32), one pass over the array instead of two.
        """
        H, W = self.grid_size
        feature_size = H * W
        out = np.empty_like(X)
        np.clip(X[:, :feature_size], 0, 5, out=out[:, :feature_size])                            # density
        np.clip(X[:, feature_size:2*feature_size], -5, 5, out=out[:, feature_size:2*feature_size])  # vx
        np.clip(X[:, 2*feature_size:3*feature_size], -5, 5, out=out[:, 2*feature_size:3*feature_size])  # vy
        np.clip(X[:, 3*feature_size:], 0, 2, out=out[:, 3*feature_size:])                        # variance
        return out

    def _f_model(self, x_np_batch, model):
        """Push the ensemble through the surrogate one step.

        `torch.from_numpy` on an already-float32 buffer instead of `torch.tensor(float64,
        dtype=float32)` saves one full copy of the batch, and the device now comes from the
        model instead of being hard-coded to CPU -- with the hard-coded version a model loaded
        onto a GPU (which ENKF.main()/estimate_noise() both do) dies on a device mismatch.
        """
        N = x_np_batch.shape[0]
        x_np = np.ascontiguousarray(x_np_batch, dtype=np.float32).reshape(N, 1, *self.state_shape)
        x_torch = torch.from_numpy(x_np)
        try:
            device = next(model.parameters()).device
        except (StopIteration, AttributeError):
            device = None
        if device is not None and device.type != "cpu":
            x_torch = x_torch.to(device, non_blocking=True)
        with torch.no_grad():
            y_torch = model(x_torch, horizon=1)
        return y_torch.cpu().numpy().reshape(N, -1)

    def forecast(self, model):
        if model is None:
            X_f = self.X.copy()
        else:
            X_f = self._f_model(self.X, model)

        # Add small process noise. Deliberately in-place: X_f is float32 out of the surrogate,
        # and `X_f = X_f + noise` would promote it to float64 a line early.
        X_f += self.rng.normal(0, self._proc_step_vec, size=X_f.shape)

        ##added for bias correction
        # NOT in-place, on purpose: this is where a float32 forecast becomes float64 in the
        # reference, and the rest of the step is sensitive to that.
        #
        # This is the reference's SECOND correction path and it is NOT textbook EnKF: update()
        # accumulates an EMA of (ensemble mean - observation) per state index, and it is
        # subtracted here at FULL strength, never scaled by the Kalman gain. So it keeps
        # correcting the forecast even when the gain is ~0. use_bias=False switches it off so
        # its contribution can be separated from the gain's.
        if self.use_bias:
            X_f = X_f - self.bias_estimate[None, :]
        else:
            X_f = X_f - 0.0 * self.bias_estimate[None, :]   # same float32 -> float64 promotion

        return self._clip_bounds(X_f)

    def _record_gain_stats(self, K, P_yy, Y_ano, r_diag, regularization, obs_idx, Y_f,
                           y_obs, X_f):
        """Append one census row per assimilation. Read-only: nothing here feeds back into the
        filter, so enabling it cannot change a result.

        What it answers. The gain is K = P_xy @ pinv(P_yy) with

            P_yy = (Y_ano^T Y_ano)/(N-1)  +  diag(R)  +  regularization * I

        and the shipped regularization is 1e-3 while the ensemble has collapsed. If the third
        term dominates the first, the gain is being suppressed by a numerical guard constant
        rather than by anything physical -- a different diagnosis from "the ensemble collapsed",
        and a different fix. `ens_frac` is that comparison, per channel.

        `self_gain` is K[state index of an observation, that observation] -- the fraction of a
        cell's own innovation that reaches that same cell's state. For a scalar Kalman filter it
        would be exactly P/(P+R); here it is the closest interpretable scalar.
        """
        N = self.ensemble_size
        HW = self.grid_size[0] * self.grid_size[1]
        m = len(obs_idx)
        ens_diag = (Y_ano ** 2).sum(axis=0) / (N - 1)          # diag of the ensemble term
        self_gain = K[obs_idx, np.arange(m)]                   # (m,)
        chan = obs_idx // HW                                   # which of the 4 fields each row is
        innov = y_obs - Y_f.mean(axis=0)                       # the mean innovation
        incr = K @ innov                                       # what the analysis actually moves
        row = {"m": int(m),
               "reg": float(regularization),
               "incr_norm": float(np.linalg.norm(incr)),
               "state_norm": float(np.linalg.norm(X_f.mean(axis=0))),
               "innov_norm": float(np.linalg.norm(innov)),
               "bias_norm": float(np.linalg.norm(self.bias_estimate)),
               "per_channel": {}}
        for c in range(self.num_features):
            sel = chan == c
            if not sel.any():
                continue
            e, r = float(ens_diag[sel].mean()), float(r_diag[sel].mean())
            row["per_channel"][c] = {
                "ens": e, "R": r,
                "ens_frac": e / (e + r + regularization),
                "self_gain_mean": float(self_gain[sel].mean()),
                "self_gain_max": float(np.abs(self_gain[sel]).max()),
            }
        self.gain_stats.append(row)

    def _localization_matrix_ref(self, obs_cells):
        """ORIGINAL implementation, kept verbatim as the correctness reference.

        Only used by tests: every result produced with the vectorised version below must be
        bit-identical to this one. See enkf_opt/README.md.
        """
        H, W = self.grid_size
        num_obs = len(obs_cells)
        loc_matrix = np.zeros((num_obs, self.state_dim))

        for i, (r_obs, c_obs) in enumerate(obs_cells):
            for f in range(self.num_features):
                for r in range(H):
                    for c in range(W):
                        # Distance-based weight
                        dist = np.sqrt((r - r_obs)**2 + (c - c_obs)**2)
                        if dist <= self.localization_radius:
                            col_idx = f * H * W + r * W + c
                            loc_matrix[i, col_idx] = np.exp(-(dist**2)/(2*(self.localization_radius**2)))
        return loc_matrix

    def _localization_weights(self, obs_cells):
        """One (num_obs, H*W) block of localization weights — the tile-free core of
        `_localization_matrix`.

        Vectorised rewrite of _localization_matrix_ref. Same mathematics, same output — the
        original ran a four-deep Python loop over len(obs_cells) x num_features x H x W
        (252 x 4 x 36 x 12 per call here), which profiling showed to be 96% of total EnKF
        runtime, against 2% for the actual Kalman algebra (pinv/SVD).

        The float sequence is reproduced EXACTLY, not simplified:
          * the squared distance is square-rooted and then squared again, as in the original;
            folding that away changes the last bits and breaks bit-identity,
          * the radius test is applied to the square-rooted distance,
          * `exp` is evaluated only on the cells that pass the radius test instead of on the
            whole grid and then masked; elementwise, so the surviving values are identical.
            Most rows keep nothing (see the note in update() about the fallback cell mapping),
            which is why this is worth doing.

        Weights do not depend on the feature index f (col_idx = f*H*W + r*W + c), so the full
        (num_obs, state_dim) matrix is this block repeated num_features times across each row.
        update() broadcasts against this block instead of materialising the repeat.
        """
        H, W = self.grid_size
        obs = np.asarray(obs_cells)                                  # (num_obs, 2)
        num_obs = len(obs)
        if num_obs == 0:
            return np.zeros((0, H * W))

        dr = np.arange(H)[None, :, None] - obs[:, 0, None, None]     # (num_obs, H, 1)
        dc = np.arange(W)[None, None, :] - obs[:, 1, None, None]     # (num_obs, 1, W)
        dist = np.sqrt(dr ** 2 + dc ** 2)                            # (num_obs, H, W)
        inside = dist <= self.localization_radius
        w = np.zeros(dist.shape)
        d_in = dist[inside]
        w[inside] = np.exp(-(d_in ** 2) / (2 * (self.localization_radius ** 2)))
        return w.reshape(num_obs, H * W)

    def _localization_matrix(self, obs_cells):
        """
        Create a diagonal localization matrix for observations.
        Only cells within `self.localization_radius` will influence updates.

        Full (num_obs, state_dim) form, kept for callers and for the bit-identity test against
        `_localization_matrix_ref`. `update()` itself uses `_localization_weights` and
        broadcasts, which avoids building and writing this 14 MB tile every step.
        """
        w = self._localization_weights(obs_cells)
        if w.shape[0] == 0:
            return np.zeros((0, self.state_dim))
        return np.tile(w, (1, self.num_features))

    def update(self, X_f, C, y_obs, observed_cells=None, regularization=1e-3, obs_idx=None):
        """
        X_f: f(ensemble) (N, state_dim)
        C: observation matrix
        y_obs: observation vector
        observed_cells: list of tuples (r,c) of observed positions
        obs_idx: optional, the state index each row of C selects. Callers that build C
                 themselves (checks/run_enkf_baseline.py, checks/bench_speed.py) already know
                 this and can pass it to skip the scan of C entirely.

        The reference computed the localization matrix twice, C.nonzero() three times and the
        ensemble anomalies twice per call, all with identical arguments and no state change in
        between (the second block at lines 350-357 of enkf_lab/ENKF.py is dead recomputation).
        Everything below is computed once. No arithmetic is reordered in the "pinv" gain mode.
        """
        N = self.ensemble_size
        F, W = self.num_features, self.grid_size[1]
        HW = self.grid_size[0] * W
        y_obs = np.asarray(y_obs)

        if obs_idx is None:
            obs_idx, is_selection = _obs_indices(C)
        else:
            obs_idx, is_selection = np.asarray(obs_idx), True

        if observed_cells is None:
            # Reference fallback, reproduced rather than fixed: the state index is split as if
            # it were a plain (row, col) pair, so for feature f the "row" comes out as f*H + r,
            # i.e. off the grid for f > 0. Those rows end up with all-zero localization weights
            # (nothing on the grid is within the radius), which is exactly why the active-column
            # shortcut in the "ensemble" gain mode pays off so well here. This is the behaviour
            # every published number was produced with, so it stays.
            #
            # MEASURED CONSEQUENCE (checks/diag_gain_census.py): with H=36 and radius=7 this
            # zeroes the gain for 100% of the vx / vy / var observation rows and leaves only
            # density assimilated -- the self-gain K[own state index, own observation] is
            # exactly 0.0 for those three fields, on every frame, because the fallback moves
            # each observation's centre f*H rows away from its own cell. Every EnKF number in
            # this repo, and in the upstream paper, was produced by a filter that assimilated
            # one of its four fields. fix_localization=True restores the intended mapping by
            # putting back the feature-block division the reference dropped:
            #     i = f*HW + r*W + c   ->   r = (i % HW) // W,   c = i % W
            # which is exactly the decode GeneratePartialObs.reconstruct_observation() already
            # does correctly in the same file. Off by default; the published path is untouched.
            rows = ((obs_idx % HW) // W) if self.fix_localization else (obs_idx // W)
            observed_cells = np.stack((rows, obs_idx % W), axis=1)

        # Localization, as one (m, H*W) block; the (m, state_dim) tile is never materialised.
        Loc_w = self._localization_weights(observed_cells)

        if self.gain_mode == "ensemble" and is_selection:
            # C is a selection matrix, so C @ X_f.T is a gather. Exact, and it skips an
            # m x state_dim x N product. Only in this mode: the matmul's output is
            # Fortran-ordered, and np.mean's summation order depends on that layout, so the
            # gather is not bit-identical to the matmul even though the values it reads are.
            Y_f = np.take(X_f, obs_idx, axis=1)
        else:
            Y_f = (C @ X_f.T).T

        y_mean = np.mean(Y_f, axis=0)
        X_mean = np.mean(X_f, axis=0)
        ##aded to remove bias
        obs_bias = y_mean - y_obs
        ##

        X_ano = X_f - X_mean
        Y_ano = Y_f - y_mean

        ####aded to remove bias
        state_bias = self._backproject_obs_bias(obs_idx, obs_bias)
        mask = state_bias != 0
        alpha = self.bias_ema_alpha
        self.bias_estimate[mask] = (1 - alpha) * self.bias_estimate[mask] + alpha * state_bias[mask]
        ###

        r_diag = self.obs_noise_vec[obs_idx] ** 2          # was np.diag(R), R never needed dense
        r_sqrt = np.sqrt(r_diag)                           # was recomputed on every member

        if self.gain_mode == "pinv":
            P_xy = (X_ano.T @ Y_ano) / (N - 1)
            # R and regularization*eye are diagonal: add them onto the diagonal in place rather
            # than materialising two dense m x m matrices (8 MB each at m=1008) to add whole.
            P_yy = (Y_ano.T @ Y_ano) / (N - 1)
            _add_to_diagonal(P_yy, r_diag)
            _add_to_diagonal(P_yy, regularization)

            # Apply localization: multiply K by Loc.T element-wise. Broadcasting over the
            # feature blocks instead of tiling Loc first — same products, 14 MB less traffic.
            K = P_xy @ np.linalg.pinv(P_yy)
            K = (K.reshape(F, HW, -1) * Loc_w.T).reshape(self.state_dim, -1)

            # Update ensemble. The member loop is kept: batching it into one GEMM changes the
            # summation order and so the last bits. The perturbation draws are unchanged --
            # RandomState fills row-major, so one (N, m) draw would give the same numbers, but
            # the matmul that would justify it is what breaks identity, not the draw.
            if self.collect_stats:
                self._record_gain_stats(K, P_yy, Y_ano, r_diag, regularization, obs_idx, Y_f,
                                        y_obs, X_f)

            X_a = np.empty_like(X_f)
            for i in range(N):
                perturbed_y = y_obs + self.rng.normal(0, r_sqrt)
                X_a[i] = X_f[i] + K @ (perturbed_y - Y_f[i])
        else:
            X_a = self._update_ensemble_space(X_f, Y_f, X_ano, Y_ano, y_obs,
                                             Loc_w, r_diag, r_sqrt, regularization)

        if not self.use_gain:
            # Diagnostic arm (use_gain=False): drop the Kalman increment but keep everything
            # that produced it. The perturbation draws above are still consumed, so this arm
            # sees the identical RNG stream to the use_gain=True arm and the two differ ONLY in
            # whether the increment is applied -- a paired comparison, not two separate runs.
            # bias_estimate has already been accumulated above, so use_gain=False + use_bias=True
            # isolates the non-standard bias path on its own.
            X_a = X_f.copy()

        # Inflation: X_mean + inflation*(X_a - X_mean), in place, two temporaries fewer.
        X_mean = np.mean(X_a, axis=0)
        X_a -= X_mean
        X_a *= self.inflation
        X_a += X_mean

        # Clip after inflation
        self.X = self._clip_bounds(X_a)
        return self.X

    def _update_ensemble_space(self, X_f, Y_f, X_ano, Y_ano, y_obs,
                               Loc_w, r_diag, r_sqrt, regularization):
        """Analysis step with the gain evaluated in ensemble space (gain_mode="ensemble").

        P_yy = c*Y_ano^T Y_ano + D with D = diag(r_diag) + regularization*I diagonal and
        c = 1/(N-1), and P_xy = X_ano^T (c*Y_ano). Woodbury then collapses the whole gain to

            P_xy P_yy^-1  =  X_ano^T A^-1 Md,     Md = c*Y_ano D^-1,   A = I_N + Md Y_ano^T

        with A only N x N. That replaces an m x m SVD (pinv, O(m^3)) plus an
        state_dim x m x m product with an N x N solve plus one state_dim x N x m product:
        ~0.2 GFLOP instead of ~14 GFLOP at m=1008, N=100, state_dim=1728. A = I + c*Y_ano D^-1
        Y_ano^T is symmetric positive definite with eigenvalues >= 1, so this route is also
        better conditioned than forming P_yy^-1 at all.

        Two further shortcuts, both exact given the above:
          * observations whose localization row is all zero get an all-zero gain column and
            therefore contribute nothing; they are dropped from the two big products. Under the
            fallback cell mapping that is ~70% of the rows.
          * the member loop becomes one GEMM (the perturbation draws are identical: RandomState
            fills the (N, m) block row-major, i.e. in the same order the loop drew them).

        Not bit-identical to gain_mode="pinv" -- same gain, different rounding.
        """
        N = self.ensemble_size
        F = self.num_features
        HW = self.grid_size[0] * self.grid_size[1]
        m = Loc_w.shape[0]

        d = r_diag + regularization
        Md = (Y_ano / (N - 1)) / d                      # (N, m)
        A = Md @ Y_ano.T                                # (N, N)
        _add_to_diagonal(A, 1.0)
        Z = np.linalg.solve(A, Md)                      # (N, m)

        active = np.flatnonzero(Loc_w.any(axis=1))
        if len(active) == m:
            G = X_ano.T @ Z
            K = (G.reshape(F, HW, m) * Loc_w.T).reshape(self.state_dim, m)
            innov = (y_obs + self.rng.normal(0, r_sqrt, size=(N, m))) - Y_f
        else:
            noise = self.rng.normal(0, r_sqrt, size=(N, m))     # full draw: same RNG stream
            G = X_ano.T @ Z[:, active]                          # (state_dim, n_active)
            K = (G.reshape(F, HW, len(active)) * Loc_w[active].T).reshape(self.state_dim, -1)
            innov = (y_obs[active] + noise[:, active]) - Y_f[:, active]

        # astype keeps the analysis in X_f's dtype, as the member loop does by writing into an
        # empty_like(X_f); without it a float32 forecast would come back promoted.
        X_a = (X_f + innov @ K.T).astype(X_f.dtype, copy=False)
        if not np.isfinite(X_a).all():
            # The driver treats a failed analysis as "forecast only" via LinAlgError; the pinv
            # path signals that through the SVD, so this path has to signal it too.
            raise np.linalg.LinAlgError("ensemble-space analysis produced non-finite values")
        return X_a

    def step(self, C, y_obs, observed_cells=None, model=None, obs_idx=None):
        X_f = self.forecast(model=model)
        X_a = self.update(X_f, C, y_obs, observed_cells=observed_cells, obs_idx=obs_idx)
        return X_a.mean(axis=0).reshape(self.state_shape)

def evaluate_enkf(localization_radius, data, model, GRID_SIZE, STATE_SHAPE,
                  PROC_STD, OBS_STD, ENSEMBLE_SIZE=50, NUM_AGENTS=3, SENSING_RANGE=2, NUM_STEPS=20):
    """
    Run one experiment with a given localization_radius and return RMSE over time.
    """
    enkf = LocalizedEnsembleKalmanFilter(
        grid_size=GRID_SIZE,
        state_shape=STATE_SHAPE,
        ensemble_size=ENSEMBLE_SIZE,
        proc_noise_std=PROC_STD,
        obs_noise_std=OBS_STD,
        localization_radius=localization_radius
    )

    # Initialize ensemble with prior
    STATE_DIM = np.prod(STATE_SHAPE)
    X_init = np.zeros((ENSEMBLE_SIZE, STATE_DIM))
    for f, std in enumerate(PROC_STD):
        start = f * GRID_SIZE[0] * GRID_SIZE[1]
        end = (f + 1) * GRID_SIZE[0] * GRID_SIZE[1]
        X_init[:, start:end] = np.random.normal(0, std, size=(ENSEMBLE_SIZE, GRID_SIZE[0] * GRID_SIZE[1]))
    enkf.X = X_init

    # Multi-agent observation setup
    agents = MultiAgent(GRID_SIZE, STATE_SHAPE, sensing_range=SENSING_RANGE, num_agents=NUM_AGENTS)

    rmse_per_step = []

    for step_idx, (x_in, _) in enumerate(data):
        if step_idx >= NUM_STEPS:
            break

        # Move agents one step
        agents.move_agents()

        # Build joint observation matrix
        C_joint, observed_cells = agents.get_joint_observation()

        # True state
        true_state = x_in.squeeze(0).squeeze(0).numpy().flatten()

        # Simulate noisy observations
        obs_vector = C_joint @ true_state
        obs_noise_vec = np.concatenate([np.full(GRID_SIZE[0]*GRID_SIZE[1], s) for s in OBS_STD])
        obs_vector += np.random.normal(0, obs_noise_vec[C_joint.nonzero()[1]], size=obs_vector.shape)

        # Forecast + update
        estimated_full = enkf.step(C_joint, obs_vector, model=model)

        # Compute RMSE for this step
        rmse = np.sqrt(np.mean((estimated_full.flatten() - true_state.flatten())**2))
        rmse_per_step.append(rmse)

    return rmse_per_step
import numpy as np
import torch
def estimate_obs_std_from_noisy_sim(data, GRID_SIZE, STATE_SHAPE, agents_factory,
                                    OBS_STD_assumed, num_steps=200, seed=0):
    """
    Estimate obs std per feature by simulating the measurement step with noise exactly
    the same way you do in main() and computing std of (noisy_obs - true_obs).
    - agents_factory: lambda returning MultiAgent(GRID_SIZE, STATE_SHAPE, sensing_range=..., num_agents=...)
    - OBS_STD_assumed: per-feature observer std you currently assume (used to generate noisy obs)
    Returns: obs_std_est per feature (length F)
    """
    rng = np.random.RandomState(seed)
    H, W = GRID_SIZE
    F = STATE_SHAPE[0]
    total_cells = H * W
    resid_lists = {f: [] for f in range(F)}

    steps = 0
    for step_idx, (x_in, _) in enumerate(data):
        if steps >= num_steps:
            break
        true_state = x_in.squeeze(0).squeeze(0).numpy().flatten()
        agents = agents_factory()
        C_joint, observed_cells = agents.get_joint_observation()
        y_true = C_joint @ true_state

        # Build per-cell obs noise vector (same as in main)
        obs_noise_vec = np.concatenate([np.full(total_cells, s) for s in OBS_STD_assumed])

        # Add noise exactly like main()
        obs_idx = C_joint.nonzero()[1]
        y_noisy = y_true + rng.normal(0, obs_noise_vec[obs_idx], size=y_true.shape)

        # Residuals per feature
        for k, state_idx in enumerate(obs_idx):
            f = state_idx // total_cells
            resid_lists[f].append(y_noisy[k] - (true_state[state_idx]))

        steps += 1

    obs_std_est = np.array([np.std(resid_lists[f]) if len(resid_lists[f])>0 else 0.0 for f in range(F)])
    return obs_std_est

def estimate_noise_from_data(data, model, GRID_SIZE, STATE_SHAPE, agents_factory,
                             num_steps=200, device="cpu"):
    """
    Returns:
      obs_std_est: array shape (num_features,) estimated obs std (global per-feature)
      proc_std_est: array shape (num_features,) estimated process std (global per-feature)
    agents_factory: function -> returns a MultiAgent instance (so you can vary sensing)
    """
    H, W = GRID_SIZE
    F = STATE_SHAPE[0]
    total_cells = H * W

    obs_resid_list = {f: [] for f in range(F)}
    model_err_list = {f: [] for f in range(F)}

    steps = 0
    for step_idx, (x_in, x_target) in enumerate(data):
        if steps >= num_steps:
            break

        # x_in: t, x_target: t+1 (depending on your loader)
        true_t = x_in.squeeze(0).squeeze(0).numpy().flatten()
        true_tp1 = x_target.squeeze(0).squeeze(0).numpy().flatten()

        # Build agents and obs for this timestep
        agents = agents_factory()
        C_joint, observed_cells = agents.get_joint_observation()

        # Simulate observation noisy (but we want residual wrt true)
        # here we use ideal observation (no noise) to measure sensor noise if dataset provides real obs.
        obs_vector = C_joint @ true_t

        # For obs residuals: compare obs_vector (simulated observation) with true_t at those indices
        obs_idx = C_joint.nonzero()[1]
        # Each obs row corresponds to a single state index
        for k, state_idx in enumerate(obs_idx):
            f = state_idx // total_cells
            val_obs = obs_vector[k]
            val_true = true_t[state_idx]
            obs_resid_list[f].append(val_obs - val_true)

        # For model/process error: predict from true_t using model
        with torch.no_grad():
            x_torch = torch.tensor(true_t.reshape(1, 1, *STATE_SHAPE), dtype=torch.float32).to(device)
            y_torch = model(x_torch, horizon=1)
            y_np = y_torch.cpu().numpy().reshape(-1)
        # model error per feature block (average over cells)
        for f in range(F):
            start = f * total_cells
            end = (f+1) * total_cells
            err_vec = y_np[start:end] - true_tp1[start:end]
            model_err_list[f].extend(err_vec.flatten().tolist())

        steps += 1

    # Aggregate to per-feature stds
    obs_std_est = np.array([np.std(obs_resid_list[f]) if len(obs_resid_list[f])>0 else 0.0 for f in range(F)])
    proc_std_est = np.array([np.std(model_err_list[f]) if len(model_err_list[f])>0 else 0.0 for f in range(F)])

    return obs_std_est, proc_std_est

def estimate_noise():
    params = {
        "NUM_AGENTS": 3,
        "SENSING_RANGE": 5,
        "ENSEMBLE_SIZE": 400,
        "NUM_STEPS": 20,
        "PROC_STD": [0.05, 0.3, 0.2, 0.01],
        "OBS_STD": [0.057, 0.317, 0.086, 0.0065],
        "GRID_SIZE": [36, 12],
        "STATE_SHAPE": [4, 36, 12],
        "Loc_radius": 5,
        "MODEL_PATH": 'pedpred/models/pretty-filly_train_model_28D_1step_20epoch.pth',
        "DEVICE": "cuda" if torch.cuda.is_available() else "cpu",
        "comment": "apply bias estimation + trust observation less (increase its var)"
    }

    # Save parameters to YAML
    # param_file = os.path.join(run_dir, "run_parameters.yaml")
    # with open(param_file, 'w') as f:
    #     yaml.dump(params, f)

    GRID_SIZE = tuple(params["GRID_SIZE"])
    STATE_SHAPE = tuple(params["STATE_SHAPE"])
    ENSEMBLE_SIZE = params["ENSEMBLE_SIZE"]
    PROC_STD = np.array(params["PROC_STD"])
    OBS_STD = np.array(params["OBS_STD"])
    SENSING_RANGE = params["SENSING_RANGE"]
    NUM_AGENTS = params["NUM_AGENTS"]
    NUM_STEPS = 30
    Loc_radius = params["Loc_radius"]
    PROC_STD = PROC_STD * 2
    OBS_STD = OBS_STD * 2
    # Load data & model
    data = get_data('test2', n_in=1, n_out=1)
    DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
    model = load_model('pedpred/models/pretty-filly_train_model_28D_1step_20epoch.pth', DEVICE)
    # model = None

    # Initialize ensemble with prior
    STATE_DIM = np.prod(STATE_SHAPE)
    STATE_DIM = np.prod(STATE_SHAPE)

    X_init = np.zeros((ENSEMBLE_SIZE, STATE_DIM))
    for f, std in enumerate(PROC_STD):
        start = f * GRID_SIZE[0] * GRID_SIZE[1]
        end = (f + 1) * GRID_SIZE[0] * GRID_SIZE[1]
        X_init[:, start:end] = np.random.normal(0, std, size=(ENSEMBLE_SIZE, GRID_SIZE[0] * GRID_SIZE[1]))

    enkf = LocalizedEnsembleKalmanFilter(grid_size=GRID_SIZE, state_shape=STATE_SHAPE,
                                         ensemble_size=ENSEMBLE_SIZE, proc_noise_std=PROC_STD,
                                         obs_noise_std=OBS_STD, inflation=1, localization_radius=Loc_radius)
    enkf.X = X_init
    # X_init = np.zeros((ENSEMBLE_SIZE, STATE_DIM))
    # agents_factory = lambda: MultiAgent(GRID_SIZE, STATE_SHAPE, sensing_range=2, num_agents=3)
    # obs_std_est, proc_std_est = estimate_noise_from_data(data, model, GRID_SIZE, STATE_SHAPE, agents_factory,
    #                                                      num_steps=100, device=DEVICE)
    # print("Obs std per feature:", obs_std_est)
    # print("Proc std per feature:", proc_std_est)
    agents_factory = lambda: MultiAgent(GRID_SIZE, STATE_SHAPE, sensing_range=SENSING_RANGE, num_agents=NUM_AGENTS)
    # supply your assumed OBS_STD used to simulate sensors in main (if you used none, decide a plausible starting one)
    # OBS_STD_assumed = np.array([0.057, 0.317, 0.086, 0.0065])  # or change to sensor specs
    # obs_std_est = estimate_obs_std_from_noisy_sim(data, GRID_SIZE, STATE_SHAPE, agents_factory, OBS_STD_assumed,
    #                                               num_steps=100)
    # print("Estimated noisy obs std per feature:", obs_std_est)
    ratios = []
    for step_idx, (x_in, _) in enumerate(data):
        if step_idx >= NUM_STEPS: break
        Xf = enkf.forecast(model)
        agents = agents_factory()
        C, _ = agents.get_joint_observation()
        true_state = x_in.squeeze(0).squeeze(0).numpy().flatten()
        y = C @ true_state
        Yf = (C @ Xf.T).T  # (N, m)
        d = y - Yf.mean(axis=0)
        obs_idx = C.nonzero()[1]
        pred_var = np.var(Yf, axis=0) + enkf.obs_noise_vec[obs_idx] ** 2
        ratios.append(np.mean((d ** 2) / (pred_var + 1e-12)))
    print("innovation ratios (per step):", ratios)
    print("mean ratio:", np.mean(ratios))



def main():
    run_dir = create_run_folder(base_dir="runs")  # create folder for this run

    # Hyperparameters
    # --- Hyperparameters ---
    OBS_STD_use = np.array([0.05690936, 0.31472941, 0.08616199, 0.00644609])
    PROC_STD_est = np.array([0.02829307, 0.31263075, 0.12325809, 0.41680932])

    params = {
        "NUM_AGENTS": 3,
        "SENSING_RANGE": 5,
        "ENSEMBLE_SIZE": 400,
        "NUM_STEPS": 20,
        "PROC_STD": [0.02829307, 0.31263075, 0.12325809, 0.41680932],
        "OBS_STD": [0.05690936, 0.31472941, 0.08616199, 0.00644609],
        "GRID_SIZE": [36, 12],
        "STATE_SHAPE": [4, 36, 12],
        "Loc_radius": 5,
        "MODEL_PATH": 'pedpred/models/pretty-filly_train_model_28D_1step_20epoch.pth',
        "DEVICE": "cuda" if torch.cuda.is_available() else "cpu",
        "comment": "apply bias estimation + trust observation less (increase its var)"
    }

    # Save parameters to YAML
    param_file = os.path.join(run_dir, "run_parameters.yaml")
    with open(param_file, 'w') as f:
        yaml.dump(params, f)

    GRID_SIZE = tuple(params["GRID_SIZE"])
    STATE_SHAPE = tuple(params["STATE_SHAPE"])
    ENSEMBLE_SIZE = params["ENSEMBLE_SIZE"]
    PROC_STD = np.array(params["PROC_STD"])
    OBS_STD = np.array(params["OBS_STD"])
    SENSING_RANGE = params["SENSING_RANGE"]
    NUM_AGENTS = params["NUM_AGENTS"]
    NUM_STEPS = 30
    Loc_radius = params["Loc_radius"]


    # Load data & model
    data = get_data('test2', n_in=1, n_out=1)
    DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
    model = load_model('pedpred/models/pretty-filly_train_model_28D_1step_20epoch.pth',DEVICE)
    # model = None



    # Initialize ensemble with prior
    STATE_DIM = np.prod(STATE_SHAPE)

    X_init = np.zeros((ENSEMBLE_SIZE, STATE_DIM))
    for f, std in enumerate(PROC_STD):
        start = f * GRID_SIZE[0] * GRID_SIZE[1]
        end = (f + 1) * GRID_SIZE[0] * GRID_SIZE[1]
        X_init[:, start:end] = np.random.normal(0, std, size=(ENSEMBLE_SIZE, GRID_SIZE[0] * GRID_SIZE[1]))

    enkf = LocalizedEnsembleKalmanFilter(grid_size=GRID_SIZE, state_shape=STATE_SHAPE,
                                ensemble_size=ENSEMBLE_SIZE, proc_noise_std=PROC_STD,
                                obs_noise_std=OBS_STD, inflation=1, localization_radius= Loc_radius)
    enkf.X = X_init  # set initial ensemble

    # --- Multi-agent simulation ---
    agents = MultiAgent(GRID_SIZE, STATE_SHAPE, sensing_range=SENSING_RANGE, num_agents=NUM_AGENTS)

    # Run filter for NUM_STEPS
    for step_idx, (x_in, _) in enumerate(data):
        print(step_idx,'***********')
        if step_idx >= NUM_STEPS:
            break

        # Move agents one step toward their goals
        agents.move_agents()

        # Build joint observation matrix
        C_joint, observed_cells = agents.get_joint_observation()

        # Simulate true observation vector with noise
        true_state = x_in.squeeze(0).squeeze(0).numpy().flatten()
        obs_vector = C_joint @ true_state
        obs_vector2 = C_joint @ true_state
        # obs_noise_vec = np.concatenate([np.full(GRID_SIZE, s) for s in OBS_STD])
        obs_noise_vec = np.concatenate([
            np.full(GRID_SIZE[0] * GRID_SIZE[1], s) for s in OBS_STD
        ])
        obs_vector += np.random.normal(0, obs_noise_vec[C_joint.nonzero()[1]], size=obs_vector.shape)

        # Forecast + update
        # Assume we have a MultiAgent or GeneratePartialObs instance for each agent
        obs_gen = GeneratePartialObs(GRID_SIZE, STATE_SHAPE, agent_pos=(0, 0), sensing_range=2)
        partial_obs = obs_gen.reconstruct_observation(obs_vector2, C_joint, fill_value=np.nan)

        estimated_full = enkf.step(C_joint, obs_vector, model = model)

        # -------------------- 🔸 DIAGNOSTIC BLOCK --------------------
        # MEAN_RESET_INTERVAL = 10  # how often to subtract mean drift
        #
        # if (step_idx + 1) % MEAN_RESET_INTERVAL == 0:
        #     # 1. compute current ensemble mean
        #     current_mean = np.mean(enkf.X, axis=0)
        #     # 2. subtract mean to recentre ensemble
        #     enkf.X = enkf.X - current_mean
        #     # 3. clip to keep within valid bounds
        #     enkf.X = enkf._clip_bounds(enkf.X)
        #     print(f"[Diagnostic] Subtracted ensemble mean at step {step_idx + 1}")
        # --------------------------------------------------------------

        estimated_spread = enkf.get_std().reshape(STATE_SHAPE)
        save_step_plot(partial_obs, true_state, estimated_full, estimated_spread, step_idx, run_dir)



if __name__ == "__main__":
    estimate_noise()

